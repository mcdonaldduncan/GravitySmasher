using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OptionManager : MonoBehaviour
{
    // option for planetary bodies to destroy on impact, only used in sandbox example
    [SerializeField] public bool destroyOnImpact;
}
